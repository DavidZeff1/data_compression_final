import java.util.PriorityQueue;
import java.util.Vector;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class Huffman {
	// input and output files
	String unCompressedFile;
	String CompressedFile;
	String deCompressedFile;
	// root of the Huffman tree
	HuffmanNode root;

	public Huffman(String unCompressedFile, String CompressedFile, String deCompressedFile) {
		// initialize the IOfiles although we might not actually be instantiating the
		// files this way due to the GUI functionality
		this.unCompressedFile = unCompressedFile;
		this.CompressedFile = CompressedFile;
		this.deCompressedFile = deCompressedFile;
	}

	public void compress() throws IOException {

		System.out.println("Compression has begun:");
		// initialize a custom IO class that will handle reading writing to and from
		// files
		FileUtil io = new FileUtil();
		System.out.println("reading txt file...");
		// read the text from the input file
		String rawTextFromFile = io.readTextFile(this.unCompressedFile);
		System.out.println("building huffman tree...");
		// build the Huffman tree based on the input file and return the root of the
		// tree
		this.root = buildHuffmanTree(rawTextFromFile);
		// encode the text using the huffman tree
		StringBuilder encoded = new StringBuilder();
		System.out.println("encoding txt from file to bit sequence using huffman tree...");
		for (char c : rawTextFromFile.toCharArray()) {
			encoded.append(getHuffmanCode(c, this.root));
		}
		System.out.println("coverting binary sequence to a binary array...");
		// convert a binary string sequence to an actual binary array(this is the
		// compressed data)
		boolean[] bitArr = convertBinaryStringToBitArray(encoded);
		System.out.println("writing the binary array to file...");
		// write the binary array to the new compressed file
		io.writeBitsToFile(this.CompressedFile, bitArr);
		System.out.println("saving the huffman tree...");
		// save the huffman tree so that we can use it later to decompress
		saveHuffmanTree(this.CompressedFile + ".tree");
		System.out.println("Compression has finished.");
		System.out.println();

	}

	public void decompress() throws IOException, ClassNotFoundException {
		System.out.println("Decompression has begun:");
		FileUtil io = new FileUtil();
		System.out.println("reading bits from compressed file...");
		// read the binary compressed file
		boolean[] bitArr = io.readBitsFromFile(CompressedFile);
		System.out.println("loading the huffman tree...");
		// load the huffman tree from the file
		loadHuffmanTree(CompressedFile + ".tree");

		System.out.println("decoding bits to original string...");
		// decode the bit array into a string
		String decoded = decodeBitArray(bitArr, this.root);
		System.out.println("Decompression has finished.");
		System.out.println();
		// write the decode string into a decompressed file
		io.writeTextFile(this.deCompressedFile, decoded);

	}

	public HuffmanNode buildHuffmanTree(String txt) {
		char[] txt2 = txt.toCharArray();
		HashMap<Character, Integer> m = new HashMap<>();

		// Count the frequency of each character
		for (char c : txt2) {
			m.put(c, m.getOrDefault(c, 0) + 1);
		}

		Vector<HuffmanNode> list = new Vector<>();

		// Create HuffmanNode objects based on character frequencies
		m.forEach((character, frequency) -> {
			HuffmanNode node = new HuffmanNode(frequency, String.valueOf(character));
			list.add(node);
		});

		// Create a priority queue with a custom comparator that sorts by frequency in
		// ascending order
		PriorityQueue<HuffmanNode> q = new PriorityQueue<>(Comparator.comparingInt(node -> node.val));

		q.addAll(list);

		// Build the Huffman tree
		while (q.size() > 1) {
			// Merge the two nodes with the lowest frequencies
			HuffmanNode n1 = q.poll();
			HuffmanNode n2 = q.poll();

			// Create a new node representing the merged frequencies
			HuffmanNode merged = new HuffmanNode(n1.val + n2.val, n1.str + n2.str);
			merged.left = n1;
			merged.right = n2;

			// Add the merged node back to the priority queue
			q.add(merged);
		}

		// The remaining node in the queue is the root of the Huffman tree
		HuffmanNode root = q.poll();

		// Print the Huffman codes (if needed)
		return root;
	}
	// ---------------------------------------------------------------------------------------------------------------------------

	public static String getHuffmanCode(char c, HuffmanNode node) {
		if (node == null) {
			return null;
		}
		if (node.left == null && node.right == null) {
			// Leaf node (character node)
			if (node.str.charAt(0) == c) {
				return "";
			} else {
				return null;
			}
		}

		String leftCode = getHuffmanCode(c, node.left);
		if (leftCode != null) {
			return "0" + leftCode;
		}

		String rightCode = getHuffmanCode(c, node.right);
		if (rightCode != null) {
			return "1" + rightCode;
		}

		return null; // If the character is not found in the tree
	}
	// ---------------------------------------------------------------------------------------------------------------------------

	public boolean[] convertBinaryStringToBitArray(StringBuilder binaryString) {
		int length = binaryString.length();
		boolean[] bitArray = new boolean[length];

		for (int i = 0; i < length; i++) {
			char ch = binaryString.charAt(i);
			if (ch == '1') {
				bitArray[i] = true;
			} else if (ch == '0') {
				bitArray[i] = false;
			} else {
				throw new IllegalArgumentException("Invalid character in binary string: " + ch);
			}
		}

		return bitArray;
	}
	// ---------------------------------------------------------------------------------------------------------------------------

	public String decodeBitArray(boolean[] bitArray, HuffmanNode root) {
		StringBuilder decoded = new StringBuilder();
		HuffmanNode current = root;

		for (boolean bit : bitArray) {
			if (bit) {
				current = current.right;
			} else {
				current = current.left;
			}

			if (current.left == null && current.right == null) {
				// Found a leaf node (character node)
				decoded.append(current.str);
				current = root; // Reset to the root for next character
			}
		}

		return decoded.toString();
	}

	// write the Huffman tree to file
	@SuppressWarnings("resource")
	public void saveHuffmanTree(String filePath) throws IOException {
		new ObjectOutputStream(new FileOutputStream(filePath)).writeObject(this.root);


	}

	// read the Huffman tree from file
	@SuppressWarnings("resource")
	public void loadHuffmanTree(String filePath) throws IOException, ClassNotFoundException {
		this.root = (HuffmanNode) new ObjectInputStream(new FileInputStream(filePath)).readObject();


	}

}
