import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.SwingUtilities;

public class Main {

	public static void main(String[] args) throws IOException {
		
		// start up application
		HuffmanGUI gui = new HuffmanGUI();
		gui.setVisible(true);
		
		
		
//		 String parent = "C://Users//dpzef//Downloads//";
//         String filePath = parent + "_76adc00b-08f0-49ad-950c-25bf0476f1cf.png";
//         String filePath2 = parent + "newImg.png";
//         FileUtil f = new FileUtil();
//         int[] arr = f.readImageFile(filePath);
//         
//         // Ensure the width and height are set correctly for the new image
//         BufferedImage originalImage = ImageIO.read(new File(filePath));
//         
//         int width = originalImage.getWidth();
//         int height = originalImage.getHeight();
//         
//         f.writeImageFile(filePath2, arr, width, height);
//         
//         
//         int[] pixelData = f.readImageFile(filePath);
//         for (int i = 0; i < pixelData.length; i++) {
//             int pixel = pixelData[i];
//             // Example modification: invert the colors
//             int alpha = (pixel >> 24) & 0xFF;
//             int red = (pixel >> 16) & 0xFF;
//             int green = (pixel >> 8) & 0xFF;
//             int blue = pixel & 0xFF;
//             // Invert colors
//             red = 255 - red;
//             green = 255 - green;
//             blue = 255 - blue;
//             // Recombine the components back into a single int
//             pixelData[i] = (alpha << 24) | (red << 16) | (green << 8) | blue;
//         }
//         f.writeImageFile(filePath2, pixelData, width, height);



//		String unCompressedFile = "C:\\Users\\dpzef\\OneDrive\\Desktop\\Assign1_2024InputFiles (1)\\Romeo and Juliet  Entire Play.txt";
//		String CompressedFile = "C:\\Users\\dpzef\\OneDrive\\Desktop\\Assign1_2024InputFiles (1)\\CompressedFile.bin";
//		String deCompressedFile = "C:\\\\Users\\\\dpzef\\\\OneDrive\\\\Desktop\\\\Assign1_2024InputFiles (1)\\\\DecompressedFile.txt";
//		Huffman a = new Huffman(unCompressedFile, CompressedFile, deCompressedFile);
//		a.compress();
//		a.decompress();
	}

}
