import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

public class HuffmanGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField unCompressedFileField;
	private JTextField compressedFileField;
	private JTextField decompressedFileField;
	private JButton selectFileButton;
	private JButton compressButton;
	private JButton decompressButton;
	private JTextArea statusArea;

	String unCompressedFile;
	String CompressedFile;
	String deCompressedFile;

	Huffman compressionObj = new Huffman(unCompressedFile, CompressedFile, deCompressedFile);

	public HuffmanGUI() {
		this.setTitle("Huffman Compression");
		this.setSize(600, 400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(new BorderLayout());
		this.setIconImage(new ImageIcon("images/logo.png").getImage());

		// Create GUI components

		unCompressedFileField = new JTextField();
		compressedFileField = new JTextField();
		decompressedFileField = new JTextField();
		selectFileButton = new JButton("Select File");
		compressButton = new JButton("Compress");
		decompressButton = new JButton("Decompress");
		statusArea = new JTextArea();

		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(3, 3));
		panel.add(new JLabel("Uncompressed File:"));
		panel.add(unCompressedFileField);
		panel.add(selectFileButton);
		panel.add(new JLabel("Compressed File:"));
		panel.add(compressedFileField);
		panel.add(compressButton);
		panel.add(new JLabel("Decompressed File:"));
		panel.add(decompressedFileField);
		panel.add(decompressButton);

		this.add(panel, BorderLayout.NORTH);
		this.add(statusArea, BorderLayout.CENTER);

		// Add action listeners
		selectFileButton.addActionListener(new SelectFileAction());
		compressButton.addActionListener(new CompressAction());
		decompressButton.addActionListener(new DecompressAction());
	}

	// Action listener for selecting a file
	private class SelectFileAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			JFileChooser fileChooser = new JFileChooser();
			if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
				File file = fileChooser.getSelectedFile();
				unCompressedFileField.setText(file.getAbsolutePath());
				compressedFileField.setText(file.getParent() + File.separator + "CompressedFile.bin");
				decompressedFileField.setText(file.getParent() + File.separator + "DecompressedFile.txt");

				compressionObj.unCompressedFile = unCompressedFileField.getText();
				compressionObj.CompressedFile = compressedFileField.getText();
				compressionObj.deCompressedFile = decompressedFileField.getText();

			}
		}
	}

	// Action listener for compressing a file
	private class CompressAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {

			try {
				statusArea.append("started compression...\n");
				compressionObj.compress();
				statusArea.append("finished compression!\n");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

//			new CompressionTask().execute();
		}
	}

	// Action listener for decompressing a file
	private class DecompressAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			try {
				statusArea.append("started decompression...\n");
				compressionObj.decompress();
				statusArea.append("finished decompression!\n");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			// new DecompressionTask().execute();
		}
	}
//	public void redirectSystemStreams() {
//	    OutputStream out = new OutputStream() {
//	        @Override
//	        public void write(int b) throws IOException {
//	            updateTextArea(String.valueOf((char) b));
//	        }
//
//	        @Override
//	        public void write(byte[] b, int off, int len) throws IOException {
//	            updateTextArea(new String(b, off, len));
//	        }
//
//	        @Override
//	        public void write(byte[] b) throws IOException {
//	            write(b, 0, b.length);
//	        }
//	    };
//
//	    System.setOut(new PrintStream(out, true));
//	    System.setErr(new PrintStream(out, true));
//	}
//
//	private void updateTextArea(final String text) {
//	    SwingUtilities.invokeLater(() -> {
//	        statusArea.append(text);
//	        statusArea.setCaretPosition(statusArea.getDocument().getLength());
//	    });
//	}

	// Background task for compression
//	private class CompressionTask extends SwingWorker<Void, String> {
//		@Override
//		protected Void doInBackground() {
//			try {
//				Huffman huffman = new Huffman(unCompressedFileField.getText(), compressedFileField.getText(),
//						decompressedFileField.getText());
//				publish("Compression has begun:");
//				publish("reading txt file...");
//				String rawTextFromFile = new FileUtil().readTextFile(unCompressedFileField.getText());
//				publish("building huffman tree...");
//				huffman.root = huffman.buildHuffmanTree(rawTextFromFile);
//				StringBuilder encoded = new StringBuilder();
//				publish("encoding txt from file to bit sequence using huffman tree...");
//				for (char c : rawTextFromFile.toCharArray()) {
//					encoded.append(Huffman.getHuffmanCode(c, huffman.root));
//				}
//				publish("coverting binary sequence to a binary array...");
//				boolean[] bitArr = huffman.convertBinaryStringToBitArray(encoded);
//				publish("writing the binary array to file...");
//				new FileUtil().writeBitsToFile(compressedFileField.getText(), bitArr);
//				publish("Boolean array successfully written to file");
//				publish("saving the huffman tree...");
//				huffman.saveHuffmanTree(compressedFileField.getText() + ".tree");
//				publish("Compression has finished.");
//			} catch (IOException ex) {
//				publish("An error occurred during compression: " + ex.getMessage());
//			}
//			return null;
//		}
//
//		@Override
//		protected void process(java.util.List<String> chunks) {
//			for (String message : chunks) {
//				statusArea.append(message + "\n");
//			}
//		}
//
//	}
//
//	// Background task for decompression
//	private class DecompressionTask extends SwingWorker<Void, String> {
//		@Override
//		protected Void doInBackground() {
//			try {
//				Huffman huffman = new Huffman(unCompressedFileField.getText(), compressedFileField.getText(),
//						decompressedFileField.getText());
//				publish("Decompression has begun:");
//				publish("reading bits from compressed file...");
//				boolean[] bitArr2 = new FileUtil().readBitsFromFile(compressedFileField.getText());
//				publish("loading the huffman tree...");
//				huffman.loadHuffmanTree(compressedFileField.getText() + ".tree");
//				publish("decoding bits to original string...");
//				String decoded = huffman.decodeBitArray(bitArr2, huffman.root);
//				new FileUtil().writeTextFile(decompressedFileField.getText(), decoded);
//				publish("Decompression has finished.");
//			} catch (IOException | ClassNotFoundException ex) {
//				publish("An error occurred during decompression: " + ex.getMessage());
//			}
//			return null;
//		}
//
//		@Override
//		protected void process(java.util.List<String> chunks) {
//			for (String message : chunks) {
//				statusArea.append(message + "\n");
//			}
//		}
//
//	}

}
