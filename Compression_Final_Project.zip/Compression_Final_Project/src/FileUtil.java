import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

public class FileUtil {

	public String readTextFile(String filePath) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		StringBuilder content = new StringBuilder();
		int charCode;
		while ((charCode = reader.read()) != -1) {
			char character = (char) charCode;
			content.append(character);
		}
		reader.close();
		return content.toString();
	}

	public void writeTextFile(String filePath, String content) throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
		writer.write(content);
		writer.close();
	}

	public void writeBitsToFile(String fileName, boolean[] bitArr) throws IOException {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		int buffer = 0; // Buffer to store bits
		int bitCount = 0; // Number of bits stored in buffer

		for (boolean value : bitArr) {
			// Pack boolean value into the buffer
			buffer = buffer << 1;
			int newBit = value ? 1 : 0;
			buffer = buffer | newBit;
			bitCount++;

			// If buffer is full (8 bits), write it to the ByteArrayOutputStream
			if (bitCount == 8) {
				byteArrayOutputStream.write(buffer);
				buffer = 0;
				bitCount = 0;
			}
		}

		// If there are remaining bits in the buffer, pad them and write to the
		// ByteArrayOutputStream
		if (bitCount > 0) {
			buffer <<= (8 - bitCount);
			byteArrayOutputStream.write(buffer);
		}

		// Write the accumulated bytes to the file in one go
		try (FileOutputStream fos = new FileOutputStream(fileName)) {
			byteArrayOutputStream.writeTo(fos);
		}

		System.out.println("Boolean array successfully written to file");
	}

	public boolean[] readBitsFromFile(String fileName) throws IOException {
		// Read all bytes from the file at once
		FileInputStream fis = new FileInputStream(fileName);
		byte[] bytes = fis.readAllBytes();
		fis.close(); // Close the file input stream

		// List to accumulate bits
		List<Boolean> bitList = new ArrayList<>();

		for (byte b : bytes) {
			for (int i = 7; i >= 0; i--) {
				// Extract each bit from the byte and add it to bitList
				boolean bit = ((b >> i) & 1) == 1;
				bitList.add(bit);
			}
		}

		// Convert the List<Boolean> to boolean[]
		boolean[] bitArr = new boolean[bitList.size()];
		for (int i = 0; i < bitList.size(); i++) {
			bitArr[i] = bitList.get(i);
		}

		return bitArr;
	}

	public int[] readImageFile(String filePath) throws IOException {
        BufferedImage image = ImageIO.read(new File(filePath));
        int width = image.getWidth();
        int height = image.getHeight();
        int[] pixelData = new int[width * height];
        image.getRGB(0, 0, width, height, pixelData, 0, width);
        return pixelData;
    }

    public void writeImageFile(String filePath, int[] pixelData, int width, int height) throws IOException {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        image.setRGB(0, 0, width, height, pixelData, 0, width);
        ImageIO.write(image, "png", new File(filePath));
    }

}
