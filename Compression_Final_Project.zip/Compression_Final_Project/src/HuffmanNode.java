import java.io.Serializable;

public class HuffmanNode implements Serializable {
	//serialize so that we can write the huffman tree to a file so that we can use the tree for decompression
    private static final long serialVersionUID = 1L;
    //store value of node
	int val;
	//store sequence of characters(leafs will be just 1 character)
	String str;
	//left children
	HuffmanNode left;
	HuffmanNode right;

	public HuffmanNode(int val, String str) {
		this.val = val;
		this.str = str;
		this.left = null;
		this.right = null;
	}
}
